#ifndef READDATA_H_INCLUDED
#define READDATA_H_INCLUDED
extern void readData( int , char** , int* , double *** );
#endif // READDATA_H_INCLUDED
